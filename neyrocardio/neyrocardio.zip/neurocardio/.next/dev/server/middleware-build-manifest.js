globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_14ibvnakj0v0q._.js",
      "static/chunks/node_modules_next_dist_shared_lib_196_nl_l493zz._.js",
      "static/chunks/node_modules_next_dist_client_16lnmlosr3ca7._.js",
      "static/chunks/node_modules_next_dist_1gdrd03q-xsfc._.js",
      "static/chunks/node_modules_next_app_0yrdk3r5ni6li.js",
      "static/chunks/[next]_entry_page-loader_ts_0z3haqkb6-d3h._.js",
      "static/chunks/node_modules_react-dom_cjs_react-dom-client_development_1nq9a-7w2rk6e.js",
      "static/chunks/node_modules_react-dom_cjs_react-dom_development_0d3scg3xnfy6h.js",
      "static/chunks/node_modules_react-dom_13voigl36lis-._.js",
      "static/chunks/node_modules_10e2-xouig913._.js",
      "static/chunks/[root-of-the-server]__0l4r13lr2xywy._.js",
      "static/chunks/pages__app_0du2_q-cjzmdk._.js",
      "static/chunks/turbopack-pages__app_1vrma7lqc30ul._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_shared_lib_1-0j6dh5fmcf0._.js",
      "static/chunks/node_modules_next_dist_client_0tk8-26rtzlym._.js",
      "static/chunks/node_modules_next_dist_compiled_0pcyzt7rtv6wz._.js",
      "static/chunks/node_modules_next_dist_0d6n9_1-a3rq6._.js",
      "static/chunks/[next]_entry_page-loader_ts_1aoli7mnyw1hs._.js",
      "static/chunks/node_modules_react-dom_cjs_react-dom-client_development_1nq9a-7w2rk6e.js",
      "static/chunks/node_modules_react-dom_cjs_react-dom_development_0d3scg3xnfy6h.js",
      "static/chunks/node_modules_react-dom_13voigl36lis-._.js",
      "static/chunks/node_modules_14t9bka2qj-mh._.js",
      "static/chunks/[root-of-the-server]__02sxxpho_3e87._.js",
      "static/chunks/pages__error_1gb68scai-n28._.js",
      "static/chunks/turbopack-pages__error_13b8ltztz4835._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_03l4kld1mrwfx._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js",
    "static/chunks/1daa_next_dist_compiled_react-dom_cjs_react-dom-client_development_0mp0cp_t-ezj9.js",
    "static/chunks/1q96_modules_next_dist_compiled_react-dom_cjs_react-dom_development_1sqry0_53krp4.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_0grqycjrj6mju._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-67asdr9._.js",
    "static/chunks/node_modules_next_dist_compiled_1amofcmz--cdp._.js",
    "static/chunks/node_modules_next_dist_client_14zvornz047l2._.js",
    "static/chunks/node_modules_next_dist_1bjkg68unqmjx._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqwj2323d._.js",
    "static/chunks/_1anvha4rlo79g._.js",
    "static/chunks/turbopack-_00pkkjbg3g3xr._.js"
  ],
  "rootMainFilesTree": {
    "/_not-found/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_03l4kld1mrwfx._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js",
      "static/chunks/1daa_next_dist_compiled_react-dom_cjs_react-dom-client_development_0mp0cp_t-ezj9.js",
      "static/chunks/1q96_modules_next_dist_compiled_react-dom_cjs_react-dom_development_1sqry0_53krp4.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_0grqycjrj6mju._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-67asdr9._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcmz--cdp._.js",
      "static/chunks/node_modules_next_dist_client_14zvornz047l2._.js",
      "static/chunks/node_modules_next_dist_1bjkg68unqmjx._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqwj2323d._.js",
      "static/chunks/_1anvha4rlo79g._.js",
      "static/chunks/turbopack-_00pkkjbg3g3xr._.js",
      "static/chunks/_18x7jxupx5rou._.js"
    ],
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_03l4kld1mrwfx._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js",
      "static/chunks/1daa_next_dist_compiled_react-dom_cjs_react-dom-client_development_0mp0cp_t-ezj9.js",
      "static/chunks/1q96_modules_next_dist_compiled_react-dom_cjs_react-dom_development_1sqry0_53krp4.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_0grqycjrj6mju._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-67asdr9._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcmz--cdp._.js",
      "static/chunks/node_modules_next_dist_client_14zvornz047l2._.js",
      "static/chunks/node_modules_next_dist_1bjkg68unqmjx._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqwj2323d._.js",
      "static/chunks/_1anvha4rlo79g._.js",
      "static/chunks/turbopack-_00pkkjbg3g3xr._.js",
      "static/chunks/_219uq1sj0q91c._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
