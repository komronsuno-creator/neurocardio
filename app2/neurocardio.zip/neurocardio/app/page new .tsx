"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Doctor = {
  name: string;
  role: string;
  description: string;
  image: string;
  phone: string;
  telegram: string;
  accent: "neuro" | "cardio";
};

type Video = {
  id: string;
  title: string;
  start?: number;
};

const doctors: Doctor[] = [
  {
    name: "Sobitjon Qurbonov",
    role: "Nevrolog",
    description: "Nevrologiya mutaxassisi",
    image: "/doctor-1.png",
    phone: "+998909105501",
    telegram: "https://t.me/sobitjon_090",
    accent: "neuro",
  },
  {
    name: "Saidburxon Turgunboyev",
    role: "Kardiolog",
    description: "Kardiologiya mutaxassisi",
    image: "/doctor-2.png",
    phone: "+998976305959",
    telegram: "https://t.me/Drsaidburxon",
    accent: "cardio",
  },
];

const directions = [
  { icon: "🧠", title: "Nevrologiya", text: "Miya va asab tizimi salomatligi", tone: "mint" },
  { icon: "❤️", title: "Kardiologiya", text: "Yurak va qon bosimi haqida", tone: "coral" },
  { icon: "🛡️", title: "Profilaktika", text: "Kasalliklarning oldini olish", tone: "violet" },
  { icon: "🌙", title: "Uyqu va stress", text: "Sog‘lom uyqu va ruhiy salomatlik", tone: "sand" },
];

const videos: Video[] = [
  { id: "Ok1ZAK3LvRA", title: "Parkinson kasalligi — sabablari" },
  { id: "LW7kcd6s_OI", title: "Yurak nega og‘riydi?", start: 55 },
  { id: "ZUxBWlhH37g", title: "Bosh aylanishi — sabablari" },
];

const menuLinks = [
  { href: "#yonalishlar", label: "Yo‘nalishlar" },
  { href: "#shifokorlar", label: "Shifokorlar" },
  { href: "#videolar", label: "Videolar" },
  { href: "#qabul", label: "Qabul" },
];

const statement =
  "Biz murakkab tibbiyotni oddiy tilda tushuntiramiz. Miya, yurak va sog‘lom turmush tarzi haqida — shifokorlar tilidan, ishonchli bilimlar bilan.";

const statementWords = statement.split(" ");

const bigMarquee = ["NEVROLOGIYA", "KARDIOLOGIYA", "PROFILAKTIKA", "SOG‘LOM UYQU"];

const SLIDE_DELAY = 4800;
const LEAVE_TIME = 1000;

export default function Home() {
  const [activeDoctor, setActiveDoctor] = useState(0);
  const [prevDoctor, setPrevDoctor] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [year, setYear] = useState(2026);

  const leaveTimer = useRef<number | null>(null);
  const activeRef = useRef(0);
  const progressRef = useRef<HTMLDivElement | null>(null);

  const goToDoctor = useCallback((next: number) => {
    if (next === activeRef.current) return;

    const previous = activeRef.current;
    activeRef.current = next;
    setPrevDoctor(previous);
    setActiveDoctor(next);

    if (leaveTimer.current) window.clearTimeout(leaveTimer.current);
    leaveTimer.current = window.setTimeout(() => setPrevDoctor(null), LEAVE_TIME);
  }, []);

  // Doktorlarni avtomatik almashtirish
  useEffect(() => {
    const timer = window.setTimeout(() => {
      goToDoctor(activeDoctor === 0 ? 1 : 0);
    }, SLIDE_DELAY);

    return () => window.clearTimeout(timer);
  }, [activeDoctor, goToDoctor]);

  useEffect(() => {
    return () => {
      if (leaveTimer.current) window.clearTimeout(leaveTimer.current);
    };
  }, []);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  // Menyu ochiq bo'lsa sahifa scrollini to'xtatish
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  // Barcha scroll effektlari bitta rAF siklida
  useEffect(() => {
    const root = document.documentElement;
    const reveals = Array.from(document.querySelectorAll<HTMLElement>(".reveal"));
    const words = Array.from(document.querySelectorAll<HTMLElement>("[data-word]"));
    const statementEl = document.querySelector<HTMLElement>("[data-statement]");
    const stackCards = Array.from(document.querySelectorAll<HTMLElement>("[data-stack]"));
    const parallaxEls = Array.from(document.querySelectorAll<HTMLElement>("[data-parallax]"));

    const clamp = (value: number, min = 0, max = 1) =>
      Math.min(max, Math.max(min, value));

    let ticking = false;

    function update() {
      ticking = false;

      const vh = window.innerHeight;
      const y = window.scrollY;
      const max = root.scrollHeight - vh;

      // Hero parallax va lentalar uchun o'zgaruvchilar
      root.style.setProperty("--sy", String(Math.min(y, vh * 1.2)));
      root.style.setProperty("--mx", String(Math.min(y, 5000)));

      // Yuqoridagi progress chizig'i
      if (progressRef.current) {
        const p = max > 0 ? clamp(y / max) : 0;
        progressRef.current.style.transform = `scaleX(${p})`;
      }

      // Scroll bilan paydo bo'ladigan elementlar
      const limit = vh * 0.92;
      reveals.forEach((el) => {
        if (el.classList.contains("is-visible")) return;
        if (el.getBoundingClientRect().top < limit) el.classList.add("is-visible");
      });

      // So'zma-so'z yonib boradigan matn
      if (statementEl && words.length) {
        const rect = statementEl.getBoundingClientRect();
        const p = clamp((vh * 0.85 - rect.top) / (rect.height + vh * 0.35));
        const total = words.length + 6;
        words.forEach((word, index) => {
          const o = clamp(p * total - index);
          word.style.opacity = String(0.16 + 0.84 * o);
        });
      }

      // Bir-birini yopadigan kartalar
      stackCards.forEach((card, index) => {
        const next = stackCards[index + 1];
        if (!next) return;
        const c = card.getBoundingClientRect();
        const n = next.getBoundingClientRect();
        const coverage = clamp(1 - (n.top - c.top - 22) / c.height);
        card.style.setProperty("--cov", coverage.toFixed(3));
      });

      // Rasmlar parallaksi
      parallaxEls.forEach((el) => {
        const parent = el.parentElement;
        if (!parent) return;
        const rect = parent.getBoundingClientRect();
        if (rect.bottom < -200 || rect.top > vh + 200) return;
        const speed = Number(el.dataset.parallax) || 0.1;
        const offset = rect.top + rect.height / 2 - vh / 2;
        el.style.transform = `translate3d(0, ${(-offset * speed).toFixed(1)}px, 0) scale(1.18)`;
      });
    }

    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(update);
    }

    // Avval ko'rinib turganlarni ochamiz, keyin yashirish rejimini yoqamiz
    update();
    root.classList.add("js-reveal");

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    window.addEventListener("load", onScroll);

    const t1 = window.setTimeout(update, 300);
    const t2 = window.setTimeout(update, 1200);

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      window.removeEventListener("load", onScroll);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      root.classList.remove("js-reveal");
    };
  }, []);

  function handleAppointment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const doctor = doctors.find((item) => item.name === selectedDoctor);

    if (!doctor) {
      alert("Iltimos, avval shifokorni tanlang.");
      return;
    }

    window.open(doctor.telegram, "_blank", "noopener,noreferrer");
  }

  const currentDoctor = doctors[activeDoctor];

  return (
    <main className="site-shell">
      <div className="progress-line" ref={progressRef} />

      {/* ============ HEADER ============ */}
      <header className="site-header">
        <a href="#bosh" className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand-heart">♥</span>
          NeuroCardio
        </a>

        <div className="header-right">
          <a className="header-cta" href="#qabul" onClick={() => setMenuOpen(false)}>
            Qabul ↗
          </a>
          <button
            type="button"
            className={`menu-button ${menuOpen ? "is-open" : ""}`}
            aria-label={menuOpen ? "Menyuni yopish" : "Menyuni ochish"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span className="menu-label">{menuOpen ? "Yopish" : "Menyu"}</span>
            <span className="menu-bars">
              <i />
              <i />
            </span>
          </button>
        </div>
      </header>

      <nav className={`menu-overlay ${menuOpen ? "is-open" : ""}`} aria-hidden={!menuOpen}>
        <ul>
          {menuLinks.map((link, index) => (
            <li key={link.href} style={{ "--i": index } as React.CSSProperties}>
              <a href={link.href} onClick={() => setMenuOpen(false)} tabIndex={menuOpen ? 0 : -1}>
                <small>0{index + 1}</small>
                {link.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          className="menu-yt"
          href="https://www.youtube.com/@Neurocardiouz"
          target="_blank"
          rel="noopener noreferrer"
          tabIndex={menuOpen ? 0 : -1}
        >
          YouTube kanali ↗
        </a>
      </nav>

      {/* ============ HERO ============ */}
      <section id="bosh" className="hero">
        <div className="hero-glow hero-glow-a" />
        <div className="hero-glow hero-glow-b" />

        <div className="hero-inner">
          <h1 className="hero-title">
            <span className="line">
              <span style={{ "--i": 0 } as React.CSSProperties}>Miya.</span>
            </span>
            <span className="line line-outline">
              <span style={{ "--i": 1 } as React.CSSProperties}>Yurak.</span>
            </span>
            <span className="line line-mint">
              <span style={{ "--i": 2 } as React.CSSProperties}>Hayot.</span>
            </span>
          </h1>

          <div className="arch-wrap">
            <div className={`arch stage-${currentDoctor.accent}`}>
              <svg className="ecg" viewBox="0 0 400 80" preserveAspectRatio="none" aria-hidden="true">
                <path d="M0 40 H110 L130 40 L145 10 L165 70 L185 25 L200 40 H400" pathLength={1} />
              </svg>

              {doctors.map((doctor, index) => {
                const state =
                  index === activeDoctor ? "is-active" : index === prevDoctor ? "is-leaving" : "";

                return (
                  <div
                    key={doctor.image}
                    className={`arch-slide ${state}`}
                    aria-hidden={index !== activeDoctor}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={doctor.image} alt={doctor.name} draggable={false} />
                  </div>
                );
              })}

              <span className="chip chip-a">🧠 Nevrologiya</span>
              <span className="chip chip-b">❤️ Kardiologiya</span>
            </div>

            <div className="arch-caption" key={currentDoctor.name}>
              <div>
                <strong>{currentDoctor.name}</strong>
                <span>{currentDoctor.role}</span>
              </div>
              <div className="arch-dots" role="tablist" aria-label="Shifokorlar">
                {doctors.map((doctor, index) => (
                  <button
                    key={doctor.name}
                    type="button"
                    role="tab"
                    aria-selected={activeDoctor === index}
                    aria-label={doctor.name}
                    className={`arch-dot ${activeDoctor === index ? "dot-active" : ""}`}
                    onClick={() => goToDoctor(index)}
                  >
                    <span key={activeDoctor === index ? `f-${activeDoctor}` : "idle"} />
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="hero-info">
            <p>
              Sog‘lom hayot ishonchli bilimdan boshlanadi. Nevrologiya, kardiologiya va umumiy
              salomatlik haqida shifokorlar tayyorlagan sodda ma’lumotlar.
            </p>

            <div className="hero-actions">
              <a className="btn btn-mint" href="#qabul">
                Qabulga yozilish <span>↗</span>
              </a>
              <a className="btn btn-ghost" href="#videolar">
                <span>▶</span> Videolar
              </a>
            </div>

            <div className="hero-stats">
              <div>
                <strong>100+</strong>
                <span>Tibbiy videolar</span>
              </div>
              <div>
                <strong>2</strong>
                <span>Mutaxassis</span>
              </div>
              <div>
                <strong>24/7</strong>
                <span>Foydali bilimlar</span>
              </div>
            </div>
          </div>
        </div>

        <a href="#yonalishlar" className="scroll-hint" aria-label="Pastga tushish">
          <span>Scroll</span>
          <i />
        </a>
      </section>

      {/* ============ STATEMENT ============ */}
      <section className="statement-section">
        <span className="tag">NEUROCARDIO HAQIDA</span>
        <p className="statement" data-statement>
          {statementWords.map((word, index) => (
            <span key={`${word}-${index}`}>
              <span data-word className="word">
                {word}
              </span>{" "}
            </span>
          ))}
        </p>
      </section>

      {/* ============ BIG MARQUEE ============ */}
      <div className="big-marquee" aria-hidden="true">
        <div className="big-row row-a">
          {[...bigMarquee, ...bigMarquee, ...bigMarquee].map((item, index) => (
            <span key={`a-${index}`}>
              {item} <i>✦</i>
            </span>
          ))}
        </div>
        <div className="big-row row-b">
          {[...bigMarquee, ...bigMarquee, ...bigMarquee].map((item, index) => (
            <span key={`b-${index}`} className="outline">
              {item} <i>✦</i>
            </span>
          ))}
        </div>
      </div>

      {/* ============ DIRECTIONS (STACK) ============ */}
      <section id="yonalishlar" className="section section-stack">
        <div className="container">
          <div className="heading reveal">
            <span className="tag">YO‘NALISHLAR</span>
            <h2>
              Salomatlik uchun <em>muhim bilimlar</em>
            </h2>
          </div>

          <div className="stack">
            {directions.map((item, index) => (
              <article
                key={item.title}
                className={`stack-card tone-${item.tone}`}
                data-stack
                style={{ "--i": index } as React.CSSProperties}
              >
                <div className="stack-top">
                  <span className="stack-num">0{index + 1}</span>
                  <span className="stack-icon">{item.icon}</span>
                </div>
                <div className="stack-bottom">
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                  <a href="#videolar">
                    Batafsil <span>↗</span>
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ DOCTORS ============ */}
      <section id="shifokorlar" className="section section-doctors">
        <div className="container">
          <div className="heading reveal">
            <span className="tag tag-dark">MUTAXASSISLAR</span>
            <h2>
              Shifokor<em>larimiz</em>
            </h2>
            <p>Mutaxassislar bilan bog‘laning va o‘zingizga kerakli ma’lumotni oling.</p>
          </div>

          <div className="doctor-grid">
            {doctors.map((doctor, index) => (
              <article key={doctor.name} className="doctor-card">
                <div className="doctor-photo reveal reveal-clip">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    loading="lazy"
                    data-parallax="0.07"
                  />
                  <span className="doctor-tag">{doctor.role}</span>
                </div>

                <div className="doctor-body reveal" style={{ "--d": `${index * 80}ms` } as React.CSSProperties}>
                  <span className="doctor-num">0{index + 1}</span>
                  <h3>{doctor.name}</h3>
                  <p>{doctor.description}</p>
                  <div className="doctor-actions">
                    <a
                      className="btn btn-ink"
                      href={doctor.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Telegram ↗
                    </a>
                    <a className="phone-link" href={`tel:${doctor.phone}`}>
                      ☎ Qo‘ng‘iroq
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ VIDEOS ============ */}
      <section id="videolar" className="section section-videos">
        <div className="container">
          <div className="heading reveal">
            <span className="tag">VIDEO KUTUBXONASI</span>
            <h2>
              Foydali <em>tibbiy videolar</em>
            </h2>
            <p>
              NeuroCardio kanalidagi salomatlik haqidagi videolarni shu sahifaning o‘zida tomosha
              qiling.
            </p>
          </div>
        </div>

        <div className="video-rail">
          <div className="video-grid">
            {videos.map((video, index) => {
              const params = new URLSearchParams({ rel: "0" });
              if (video.start) params.set("start", String(video.start));

              return (
                <article
                  key={video.id}
                  className="video-card reveal"
                  style={{ "--d": `${index * 90}ms` } as React.CSSProperties}
                >
                  <div className="video-frame">
                    <iframe
                      src={`https://www.youtube-nocookie.com/embed/${video.id}?${params.toString()}`}
                      title={video.title}
                      loading="lazy"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      referrerPolicy="strict-origin-when-cross-origin"
                      allowFullScreen
                    />
                  </div>
                  <div className="video-info">
                    <span>0{index + 1} · VIDEO</span>
                    <h3>{video.title}</h3>
                  </div>
                </article>
              );
            })}
          </div>
        </div>

        <div className="container">
          <p className="swipe-hint">Suring → </p>
          <div className="channel-link reveal">
            <a
              className="btn btn-ghost"
              href="https://www.youtube.com/@Neurocardiouz"
              target="_blank"
              rel="noopener noreferrer"
            >
              YouTube kanaliga o‘tish ↗
            </a>
          </div>
        </div>
      </section>

      {/* ============ APPOINTMENT ============ */}
      <section id="qabul" className="section section-appointment">
        <div className="container appointment-layout">
          <div className="appointment-copy reveal">
            <span className="tag tag-dark">BIZ BILAN BOG‘LANING</span>
            <h2>
              Salomatligingizga <em>bugundan</em> e’tibor bering
            </h2>
            <p>
              Kerakli shifokorni tanlang. Sizni tegishli mutaxassisning Telegram sahifasiga
              yo‘naltiramiz.
            </p>
            <ul className="appointment-points">
              <li>Mutaxassisni tanlash</li>
              <li>Telegram orqali bog‘lanish</li>
              <li>Qulay va sodda</li>
            </ul>
          </div>

          <form className="appointment-form reveal" onSubmit={handleAppointment}>
            <label htmlFor="patient-name">Ism va familiyangiz</label>
            <input
              id="patient-name"
              name="name"
              type="text"
              placeholder="Ismingizni kiriting"
              autoComplete="name"
              required
            />

            <label htmlFor="patient-phone">Telefon raqamingiz</label>
            <input
              id="patient-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              placeholder="+998 __ ___ __ __"
              autoComplete="tel"
              required
            />

            <label htmlFor="doctor-select">Shifokorni tanlang</label>
            <select
              id="doctor-select"
              value={selectedDoctor}
              onChange={(event) => setSelectedDoctor(event.target.value)}
              required
            >
              <option value="">Shifokorni tanlang</option>
              {doctors.map((doctor) => (
                <option key={doctor.name} value={doctor.name}>
                  {doctor.name} — {doctor.role}
                </option>
              ))}
            </select>

            <button className="btn btn-mint form-submit" type="submit">
              Telegram orqali bog‘lanish <span>↗</span>
            </button>

            <p className="form-note">
              Tugma tanlangan shifokorning Telegram sahifasini ochadi. Ism va telefon raqami
              avtomatik yuborilmaydi.
            </p>
          </form>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="site-footer">
        <div className="footer-word" aria-hidden="true">
          NeuroCardio
        </div>
        <div className="footer-inner">
          <p>Salomatlik haqida ishonchli ma’lumotlar.</p>
          <a
            href="https://www.youtube.com/@Neurocardiouz"
            target="_blank"
            rel="noopener noreferrer"
          >
            YouTube ↗
          </a>
        </div>
        <div className="footer-bottom">
          © {year} NeuroCardio. Barcha huquqlar himoyalangan.
        </div>
      </footer>
    </main>
  );
}
