"use client";

import { useEffect, useState } from "react";

type Doctor = {
  name: string;
  role: string;
  description: string;
  image: string;
  phone: string;
  telegram: string;
  accent: "neuro" | "cardio";
};

type Video = {
  id: string;
  title: string;
  start?: number;
};

const doctors: Doctor[] = [
  {
    name: "Sobitjon Qurbonov",
    role: "Nevrolog",
    description: "Nevrologiya mutaxassisi",
    image: "/doctor-1.png",
    phone: "+998909105501",
    telegram: "https://t.me/sobitjon_090",
    accent: "neuro",
  },
  {
    name: "Saidburxon Turgunboyev",
    role: "Kardiolog",
    description: "Kardiologiya mutaxassisi",
    image: "/doctor-2.png",
    phone: "+998976305959",
    telegram: "https://t.me/Drsaidburxon",
    accent: "cardio",
  },
];

const directions = [
  { icon: "🧠", title: "Nevrologiya", text: "Miya va asab tizimi salomatligi" },
  { icon: "❤️", title: "Kardiologiya", text: "Yurak va qon bosimi haqida" },
  { icon: "🛡️", title: "Profilaktika", text: "Kasalliklarning oldini olish" },
  { icon: "🌙", title: "Uyqu va stress", text: "Sog‘lom uyqu va ruhiy salomatlik" },
];

const videos: Video[] = [
  { id: "Ok1ZAK3LvRA", title: "Parkinson kasalligi — sabablari" },
  { id: "LW7kcd6s_OI", title: "Yurak nega og‘riydi?", start: 55 },
  { id: "ZUxBWlhH37g", title: "Bosh aylanishi — sabablari" },
];

const menuLinks = [
  { href: "#yonalishlar", label: "Yo‘nalishlar" },
  { href: "#shifokorlar", label: "Shifokorlar" },
  { href: "#videolar", label: "Videolar" },
  { href: "#qabul", label: "Qabul" },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [year, setYear] = useState(2026);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  // Telefon menyusi ochiq bo'lganda Escape bilan yopish
  useEffect(() => {
    if (!menuOpen) return;

    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setMenuOpen(false);
    }

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  // Scroll: paydo bo'lish, parallaks; sichqoncha: shisha yorug'ligi
  useEffect(() => {
    const root = document.documentElement;
    const reveals = Array.from(document.querySelectorAll<HTMLElement>(".reveal"));

    let ticking = false;

    function update() {
      ticking = false;

      const vh = window.innerHeight;
      const y = window.scrollY;

      root.style.setProperty("--sy", String(Math.min(y, vh * 1.2)));
      root.style.setProperty("--scr", String(y));

      const limit = vh * 0.93;
      reveals.forEach((el) => {
        if (el.classList.contains("is-visible")) return;
        if (el.getBoundingClientRect().top < limit) el.classList.add("is-visible");
      });
    }

    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(update);
    }

    function onPointerMove(event: PointerEvent) {
      const target = (event.target as HTMLElement | null)?.closest<HTMLElement>("[data-glow]");
      if (!target) return;
      const rect = target.getBoundingClientRect();
      target.style.setProperty("--px", `${event.clientX - rect.left}px`);
      target.style.setProperty("--py", `${event.clientY - rect.top}px`);
    }

    // Avval ko'rinib turganlarni ochamiz, keyin yashirish rejimini yoqamiz
    update();
    root.classList.add("js-reveal");

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    window.addEventListener("load", onScroll);
    window.addEventListener("pointermove", onPointerMove, { passive: true });

    const t1 = window.setTimeout(update, 300);
    const t2 = window.setTimeout(update, 1200);

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      window.removeEventListener("load", onScroll);
      window.removeEventListener("pointermove", onPointerMove);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      root.classList.remove("js-reveal");
    };
  }, []);

  function handleAppointment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const doctor = doctors.find((item) => item.name === selectedDoctor);

    if (!doctor) {
      alert("Iltimos, avval shifokorni tanlang.");
      return;
    }

    window.open(doctor.telegram, "_blank", "noopener,noreferrer");
  }

  return (
    <main className="site-shell">
      {/* Fon: suzib yuruvchi yumshoq ranglar (shisha ularni xiralashtiradi) */}
      <div className="mesh" aria-hidden="true">
        <i className="blob blob-1" />
        <i className="blob blob-2" />
        <i className="blob blob-3" />
      </div>

      {/* ============ NAV ============ */}
      <header className="nav-area">
        <nav className="nav glass">
          <a href="#bosh" className="brand" onClick={() => setMenuOpen(false)}>
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>

          <div className="nav-links">
            {menuLinks.map((link) => (
              <a key={link.href} href={link.href}>
                {link.label}
              </a>
            ))}
          </div>

          <a className="nav-cta" href="#qabul">
            Qabulga yozilish
          </a>

          <button
            type="button"
            className="menu-button"
            aria-label={menuOpen ? "Menyuni yopish" : "Menyuni ochish"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span className={`bars ${menuOpen ? "is-open" : ""}`}>
              <i />
              <i />
            </span>
          </button>
        </nav>

        <div className={`mobile-panel glass ${menuOpen ? "is-open" : ""}`} aria-hidden={!menuOpen}>
          {menuLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              tabIndex={menuOpen ? 0 : -1}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
              <span>↗</span>
            </a>
          ))}
          <a
            className="panel-cta"
            href="#qabul"
            tabIndex={menuOpen ? 0 : -1}
            onClick={() => setMenuOpen(false)}
          >
            Qabulga yozilish
          </a>
        </div>
      </header>

      {/* ============ HERO ============ */}
      <section id="bosh" className="hero">
        {/* Fon ranglari (doktorga qarab o'zgaradi) */}
        <div className="hero-bg" aria-hidden="true">
          <div className="hero-tint tint-neuro" />
          <div className="hero-tint tint-cardio" />
          <div className="hero-ring ring-a" />
          <div className="hero-ring ring-b" />
        </div>

        {/* Fondagi doktorlar */}
        <div className="hero-stage">
          {doctors.map((doctor, index) => (
            <div
              key={doctor.image}
              className="stage-slide"
              style={{ "--i": index } as React.CSSProperties}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={doctor.image} alt={doctor.name} draggable={false} />
            </div>
          ))}

          <span className="float-chip chip-a glass">🧠 Nevrologiya</span>
          <span className="float-chip chip-b glass">❤️ Kardiologiya</span>

          <div className="doctor-pill glass">
            <span className="live-dot" />
            <div className="pill-texts">
              {doctors.map((doctor, index) => (
                <div
                  key={doctor.name}
                  className="pill-text"
                  style={{ "--i": index } as React.CSSProperties}
                >
                  <strong>{doctor.name}</strong>
                  <span>{doctor.role}</span>
                </div>
              ))}
            </div>
            <div className="pill-dots" aria-hidden="true">
              {doctors.map((doctor, index) => (
                <span
                  key={doctor.name}
                  className="pill-dot"
                  style={{ "--i": index } as React.CSSProperties}
                >
                  <span />
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="hero-content">
          <div className="hero-card glass" data-glow>
            <span className="eyebrow">
              <i /> MIYA · YURAK · SALOMATLIK
            </span>

            <h1>
              Sog‘lom hayot
              <span> ishonchli bilimdan</span>
              boshlanadi
            </h1>

            <p>
              Nevrologiya, kardiologiya va umumiy salomatlik haqida shifokorlar tayyorlagan sodda
              va ishonchli ma’lumotlar.
            </p>

            <div className="hero-actions">
              <a className="btn btn-primary" href="#qabul">
                Qabulga yozilish <span>↗</span>
              </a>
              <a className="btn btn-glass" href="#videolar">
                <span>▶</span> Videolar
              </a>
            </div>

            <div className="hero-stats">
              <div>
                <strong>100+</strong>
                <span>Tibbiy videolar</span>
              </div>
              <div>
                <strong>2</strong>
                <span>Mutaxassis</span>
              </div>
              <div>
                <strong>24/7</strong>
                <span>Foydali bilimlar</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ DIRECTIONS ============ */}
      <section id="yonalishlar" className="section">
        <div className="container">
          <div className="heading reveal">
            <span className="tag">YO‘NALISHLAR</span>
            <h2>Salomatlik uchun muhim bilimlar</h2>
            <p>
              Organizmni tushunish, sog‘lom odatlarni shakllantirish va kasalliklarning oldini
              olish haqida.
            </p>
          </div>

          <div className="direction-grid">
            {directions.map((item, index) => (
              <article
                key={item.title}
                className="direction-card glass reveal"
                data-glow
                style={{ "--d": `${index * 90}ms` } as React.CSSProperties}
              >
                <div className="direction-icon">{item.icon}</div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <a href="#videolar">
                  Batafsil <span>↗</span>
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ DOCTORS ============ */}
      <section id="shifokorlar" className="section">
        <div className="container">
          <div className="heading reveal">
            <span className="tag">MUTAXASSISLAR</span>
            <h2>Shifokorlarimiz</h2>
            <p>Mutaxassislar bilan bog‘laning va o‘zingizga kerakli ma’lumotni oling.</p>
          </div>

          <div className="doctor-grid">
            {doctors.map((doctor, index) => (
              <article
                key={doctor.name}
                className={`doctor-card reveal tone-${doctor.accent}`}
                style={{ "--d": `${index * 120}ms` } as React.CSSProperties}
              >
                <div className="doctor-photo">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={doctor.image} alt={doctor.name} loading="lazy" />
                </div>

                <div className="doctor-info glass" data-glow>
                  <span className="doctor-role">{doctor.role}</span>
                  <h3>{doctor.name}</h3>
                  <p>{doctor.description}</p>
                  <div className="doctor-actions">
                    <a
                      className="btn btn-primary"
                      href={doctor.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Telegram ↗
                    </a>
                    <a className="phone-link" href={`tel:${doctor.phone}`}>
                      ☎ Qo‘ng‘iroq
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ VIDEOS ============ */}
      <section id="videolar" className="section section-videos">
        <div className="container">
          <div className="heading reveal">
            <span className="tag">VIDEO KUTUBXONASI</span>
            <h2>Foydali tibbiy videolar</h2>
            <p>
              NeuroCardio kanalidagi salomatlik haqidagi videolarni shu sahifaning o‘zida tomosha
              qiling.
            </p>
          </div>
        </div>

        <div className="video-grid">
          {videos.map((video, index) => {
            const params = new URLSearchParams({ rel: "0" });
            if (video.start) params.set("start", String(video.start));

            return (
              <article
                key={video.id}
                className="video-card glass reveal"
                style={{ "--d": `${index * 100}ms` } as React.CSSProperties}
              >
                <div className="video-frame">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${video.id}?${params.toString()}`}
                    title={video.title}
                    loading="lazy"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                  />
                </div>
                <div className="video-info">
                  <span>NEUROCARDIO · VIDEO</span>
                  <h3>{video.title}</h3>
                </div>
              </article>
            );
          })}
        </div>

        <div className="container">
          <div className="channel-link reveal">
            <a
              className="btn btn-glass"
              href="https://www.youtube.com/@Neurocardiouz"
              target="_blank"
              rel="noopener noreferrer"
            >
              YouTube kanaliga o‘tish ↗
            </a>
          </div>
        </div>
      </section>

      {/* ============ APPOINTMENT ============ */}
      <section id="qabul" className="section">
        <div className="container appointment-layout">
          <div className="appointment-copy reveal">
            <span className="tag">BIZ BILAN BOG‘LANING</span>
            <h2>Salomatligingizga bugundan e’tibor bering</h2>
            <p>
              Kerakli shifokorni tanlang. Sizni tegishli mutaxassisning Telegram sahifasiga
              yo‘naltiramiz.
            </p>
            <ul className="appointment-points">
              <li>Mutaxassisni tanlash</li>
              <li>Telegram orqali bog‘lanish</li>
              <li>Qulay va sodda</li>
            </ul>
          </div>

          <form className="appointment-form glass reveal" onSubmit={handleAppointment} data-glow>
            <label htmlFor="patient-name">Ism va familiyangiz</label>
            <input
              id="patient-name"
              name="name"
              type="text"
              placeholder="Ismingizni kiriting"
              autoComplete="name"
              required
            />

            <label htmlFor="patient-phone">Telefon raqamingiz</label>
            <input
              id="patient-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              placeholder="+998 __ ___ __ __"
              autoComplete="tel"
              required
            />

            <label htmlFor="doctor-select">Shifokorni tanlang</label>
            <select
              id="doctor-select"
              value={selectedDoctor}
              onChange={(event) => setSelectedDoctor(event.target.value)}
              required
            >
              <option value="">Shifokorni tanlang</option>
              {doctors.map((doctor) => (
                <option key={doctor.name} value={doctor.name}>
                  {doctor.name} — {doctor.role}
                </option>
              ))}
            </select>

            <button className="btn btn-primary form-submit" type="submit">
              Telegram orqali bog‘lanish <span>↗</span>
            </button>

            <p className="form-note">
              Tugma tanlangan shifokorning Telegram sahifasini ochadi. Ism va telefon raqami
              avtomatik yuborilmaydi.
            </p>
          </form>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="footer-wrap">
        <div className="site-footer glass">
          <a href="#bosh" className="brand">
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>
          <p>Salomatlik haqida ishonchli ma’lumotlar.</p>
          <a
            className="footer-link"
            href="https://www.youtube.com/@Neurocardiouz"
            target="_blank"
            rel="noopener noreferrer"
          >
            YouTube ↗
          </a>
        </div>
        <div className="footer-bottom">
          © {year} NeuroCardio. Barcha huquqlar himoyalangan.
        </div>
      </footer>
    </main>
  );
}
