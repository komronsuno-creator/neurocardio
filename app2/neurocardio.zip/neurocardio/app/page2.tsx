"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Doctor = {
  name: string;
  role: string;
  description: string;
  image: string;
  phone: string;
  telegram: string;
  accent: string;
};

type Video = {
  id: string;
  title: string;
  start?: number;
};

const doctors: Doctor[] = [
  {
    name: "Sobitjon Qurbonov",
    role: "Nevrolog",
    description: "Nevrologiya mutaxassisi",
    image: "/doctor-1.png",
    phone: "+998909105501",
    telegram: "https://t.me/sobitjon_090",
    accent: "neuro",
  },
  {
    name: "Saidburxon Turgunboyev",
    role: "Kardiolog",
    description: "Kardiologiya mutaxassisi",
    image: "/doctor-2.png",
    phone: "+998976305959",
    telegram: "https://t.me/Drsaidburxon",
    accent: "cardio",
  },
];

const directions = [
  { icon: "🧠", title: "Nevrologiya", text: "Miya va asab tizimi salomatligi" },
  { icon: "❤️", title: "Kardiologiya", text: "Yurak va qon bosimi haqida" },
  { icon: "🛡️", title: "Profilaktika", text: "Kasalliklarning oldini olish" },
  { icon: "🌙", title: "Uyqu va stress", text: "Sog‘lom uyqu va ruhiy salomatlik" },
];

const videos: Video[] = [
  { id: "Ok1ZAK3LvRA", title: "Parkinson kasalligi — sabablari" },
  { id: "LW7kcd6s_OI", title: "Yurak nega og‘riydi?", start: 55 },
  { id: "ZUxBWlhH37g", title: "Bosh aylanishi — sabablari" },
];

const marqueeItems = [
  "Nevrologiya",
  "Kardiologiya",
  "Profilaktika",
  "Sog‘lom uyqu",
  "Qon bosimi",
  "Miya salomatligi",
  "Stressni boshqarish",
];

const SLIDE_DELAY = 5000;
const LEAVE_TIME = 1100;

export default function Home() {
  const [activeDoctor, setActiveDoctor] = useState(0);
  const [prevDoctor, setPrevDoctor] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [scrollProgress, setScrollProgress] = useState(0);
  const [year, setYear] = useState(2026);

  const leaveTimer = useRef<number | null>(null);
  const activeRef = useRef(0);

  const goToDoctor = useCallback((next: number) => {
    if (next === activeRef.current) return;

    const previous = activeRef.current;
    activeRef.current = next;
    setPrevDoctor(previous);
    setActiveDoctor(next);

    if (leaveTimer.current) window.clearTimeout(leaveTimer.current);
    leaveTimer.current = window.setTimeout(() => {
      setPrevDoctor(null);
    }, LEAVE_TIME);
  }, []);

  // Doktorlarni avtomatik almashtirish (har safar timer qayta ishga tushadi)
  useEffect(() => {
    const timer = window.setTimeout(() => {
      goToDoctor(activeDoctor === 0 ? 1 : 0);
    }, SLIDE_DELAY);

    return () => window.clearTimeout(timer);
  }, [activeDoctor, goToDoctor]);

  useEffect(() => {
    return () => {
      if (leaveTimer.current) window.clearTimeout(leaveTimer.current);
    };
  }, []);

  // Yil (hydration xatosiz)
  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  // Scroll progress
  useEffect(() => {
    function onScroll() {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0);
    }

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Scroll reveal animatsiyasi
  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>(".reveal");

    if (!("IntersectionObserver" in window)) {
      elements.forEach((el) => el.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );

    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  // Menyu ochiq bo'lsa sahifa scrollini to'xtatish
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  function handleAppointment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const doctor = doctors.find((item) => item.name === selectedDoctor);

    if (!doctor) {
      alert("Iltimos, avval shifokorni tanlang.");
      return;
    }

    window.open(doctor.telegram, "_blank", "noopener,noreferrer");
  }

  const currentDoctor = doctors[activeDoctor];

  return (
    <main className="site-shell">
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />

      <header className="site-header">
        <nav className="nav-wrap">
          <a href="#bosh" className="brand" onClick={() => setMenuOpen(false)}>
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>

          <button
            type="button"
            className="mobile-menu-button"
            aria-label={menuOpen ? "Menyuni yopish" : "Menyuni ochish"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            {menuOpen ? "✕" : "☰"}
          </button>

          <div className={`nav-links ${menuOpen ? "nav-open" : ""}`}>
            <a href="#yonalishlar" onClick={() => setMenuOpen(false)}>
              Yo‘nalishlar
            </a>
            <a href="#shifokorlar" onClick={() => setMenuOpen(false)}>
              Shifokorlar
            </a>
            <a href="#videolar" onClick={() => setMenuOpen(false)}>
              Videolar
            </a>
            <a href="#qabul" onClick={() => setMenuOpen(false)}>
              Qabul
            </a>
            <a className="nav-cta" href="#qabul" onClick={() => setMenuOpen(false)}>
              Qabulga yozilish ↗
            </a>
          </div>
        </nav>
      </header>

      <section id="bosh" className="hero-section">
        <div className="aurora aurora-one" />
        <div className="aurora aurora-two" />
        <div className="aurora aurora-three" />
        <div className="hero-grid-bg" />

        <div className="hero-layout">
          <div className="hero-copy reveal">
            <span className="eyebrow">
              <i className="pulse-dot" /> MIYA · YURAK · SALOMATLIK
            </span>

            <h1>
              Sog‘lom hayot
              <span className="gradient-text"> ishonchli bilimdan</span>
              boshlanadi
            </h1>

            <p className="hero-description">
              Nevrologiya, kardiologiya va umumiy salomatlik haqida
              shifokorlar tayyorlagan sodda va ishonchli ma’lumotlar.
            </p>

            <div className="hero-actions">
              <a className="button-primary" href="#qabul">
                Qabulga yozilish <span>↗</span>
              </a>
              <a className="button-secondary" href="#videolar">
                <span>▶</span> Videolarni ko‘rish
              </a>
            </div>

            <div className="hero-stats">
              <div>
                <strong>100+</strong>
                <span>Tibbiy videolar</span>
              </div>
              <div>
                <strong>2</strong>
                <span>Mutaxassis</span>
              </div>
              <div>
                <strong>24/7</strong>
                <span>Foydali bilimlar</span>
              </div>
            </div>
          </div>

          <div className="hero-visual reveal">
            <div className="hero-ring ring-one" />
            <div className="hero-ring ring-two" />

            <div className={`doctor-stage stage-${currentDoctor.accent}`}>
              <div className="stage-backdrop" />

              <svg
                className="ecg"
                viewBox="0 0 400 80"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
                <path
                  d="M0 40 H110 L130 40 L145 10 L165 70 L185 25 L200 40 H400"
                  pathLength={1}
                />
              </svg>

              <div className="floating-label label-neuro">
                <span>🧠</span>
                <small>Nevrologiya</small>
              </div>

              <div className="floating-label label-cardio">
                <span>❤️</span>
                <small>Kardiologiya</small>
              </div>

              {doctors.map((doctor, index) => {
                const state =
                  index === activeDoctor
                    ? "is-active"
                    : index === prevDoctor
                      ? "is-leaving"
                      : "";

                return (
                  <div
                    key={doctor.image}
                    className={`doctor-slide ${state}`}
                    aria-hidden={index !== activeDoctor}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={doctor.image}
                      alt={doctor.name}
                      className="doctor-slide-image"
                      draggable={false}
                    />
                  </div>
                );
              })}

              <div className="doctor-caption" key={currentDoctor.name}>
                <span className="live-dot" />
                <div>
                  <strong>{currentDoctor.name}</strong>
                  <span>{currentDoctor.role}</span>
                </div>
                <span className="caption-heart">♥</span>
              </div>
            </div>

            <div className="slider-dots" role="tablist" aria-label="Shifokorlar">
              {doctors.map((doctor, index) => (
                <button
                  key={doctor.name}
                  type="button"
                  role="tab"
                  aria-selected={activeDoctor === index}
                  aria-label={doctor.name}
                  className={`slider-dot ${activeDoctor === index ? "dot-active" : ""}`}
                  onClick={() => goToDoctor(index)}
                >
                  <span
                    key={activeDoctor === index ? `fill-${activeDoctor}` : "idle"}
                    className="dot-fill"
                  />
                </button>
              ))}
            </div>

            <div className="hero-bottom-note">
              <span>✦</span>
              Salomatligingiz biz uchun muhim
            </div>
          </div>
        </div>

        <a href="#yonalishlar" className="scroll-cue" aria-label="Pastga tushish">
          <span />
        </a>
      </section>

      <div className="marquee" aria-hidden="true">
        <div className="marquee-track">
          {[...marqueeItems, ...marqueeItems, ...marqueeItems].map((item, index) => (
            <span key={`${item}-${index}`}>
              <i>✦</i> {item}
            </span>
          ))}
        </div>
      </div>

      <section id="yonalishlar" className="section section-directions">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">BIZNING YO‘NALISHLAR</span>
            <h2>Salomatlik uchun muhim bilimlar</h2>
            <p>
              Organizmni tushunish, sog‘lom odatlarni shakllantirish va
              kasalliklarning oldini olish haqida.
            </p>
          </div>

          <div className="direction-grid">
            {directions.map((item, index) => (
              <article
                key={item.title}
                className="direction-card glass-card reveal"
                style={{ transitionDelay: `${index * 90}ms` }}
              >
                <div className="direction-icon">{item.icon}</div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <a href="#videolar">
                  Batafsil <span>↗</span>
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="shifokorlar" className="section section-doctors">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">MUTAXASSISLAR</span>
            <h2>Shifokorlarimiz</h2>
            <p>
              Mutaxassislar bilan bog‘laning va o‘zingizga kerakli
              ma’lumotni oling.
            </p>
          </div>

          <div className="doctor-grid">
            {doctors.map((doctor, index) => (
              <article
                key={doctor.name}
                className="doctor-card glass-card reveal"
                style={{ transitionDelay: `${index * 120}ms` }}
              >
                <div className="doctor-photo-wrap">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={doctor.image} alt={doctor.name} loading="lazy" />
                  <span className="doctor-specialty">{doctor.role}</span>
                </div>
                <div className="doctor-card-body">
                  <span className="doctor-kicker">NEUROCARDIO MUTAXASSISI</span>
                  <h3>{doctor.name}</h3>
                  <p>{doctor.description}</p>
                  <div className="doctor-card-actions">
                    <a
                      className="button-primary"
                      href={doctor.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Telegram ↗
                    </a>
                    <a className="phone-link" href={`tel:${doctor.phone}`}>
                      ☎ Qo‘ng‘iroq
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="videolar" className="section section-videos">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">VIDEO KUTUBXONASI</span>
            <h2>Foydali tibbiy videolar</h2>
            <p>
              NeuroCardio kanalidagi salomatlik haqidagi videolarni shu
              sahifaning o‘zida tomosha qiling.
            </p>
          </div>

          <div className="video-grid">
            {videos.map((video, index) => {
              const params = new URLSearchParams({ rel: "0" });
              if (video.start) params.set("start", String(video.start));

              return (
                <article
                  key={video.id}
                  className="video-card glass-card reveal"
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <div className="video-frame">
                    <iframe
                      src={`https://www.youtube-nocookie.com/embed/${video.id}?${params.toString()}`}
                      title={video.title}
                      loading="lazy"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      referrerPolicy="strict-origin-when-cross-origin"
                      allowFullScreen
                    />
                  </div>
                  <div className="video-info">
                    <span>NEUROCARDIO · VIDEO</span>
                    <h3>{video.title}</h3>
                  </div>
                </article>
              );
            })}
          </div>

          <div className="channel-link-wrap reveal">
            <a
              className="button-secondary"
              href="https://www.youtube.com/@Neurocardiouz"
              target="_blank"
              rel="noopener noreferrer"
            >
              YouTube kanaliga o‘tish ↗
            </a>
          </div>
        </div>
      </section>

      <section id="qabul" className="section section-appointment">
        <div className="section-container appointment-layout">
          <div className="appointment-copy reveal">
            <span className="eyebrow">BIZ BILAN BOG‘LANING</span>
            <h2>Salomatligingizga bugundan e’tibor bering</h2>
            <p>
              Kerakli shifokorni tanlang. Sizni tegishli mutaxassisning
              Telegram sahifasiga yo‘naltiramiz.
            </p>
            <div className="appointment-points">
              <span>✓ Mutaxassisni tanlash</span>
              <span>✓ Telegram orqali bog‘lanish</span>
              <span>✓ Qulay va sodda</span>
            </div>
          </div>

          <form
            className="appointment-form glass-card reveal"
            onSubmit={handleAppointment}
          >
            <label htmlFor="patient-name">Ism va familiyangiz</label>
            <input
              id="patient-name"
              name="name"
              type="text"
              placeholder="Ismingizni kiriting"
              autoComplete="name"
              required
            />

            <label htmlFor="patient-phone">Telefon raqamingiz</label>
            <input
              id="patient-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              placeholder="+998 __ ___ __ __"
              autoComplete="tel"
              required
            />

            <label htmlFor="doctor-select">Shifokorni tanlang</label>
            <select
              id="doctor-select"
              value={selectedDoctor}
              onChange={(event) => setSelectedDoctor(event.target.value)}
              required
            >
              <option value="">Shifokorni tanlang</option>
              {doctors.map((doctor) => (
                <option key={doctor.name} value={doctor.name}>
                  {doctor.name} — {doctor.role}
                </option>
              ))}
            </select>

            <button className="button-primary form-submit" type="submit">
              Telegram orqali bog‘lanish <span>↗</span>
            </button>

            <p className="form-note">
              Tugma tanlangan shifokorning Telegram sahifasini ochadi.
              Ism va telefon raqami avtomatik yuborilmaydi.
            </p>
          </form>
        </div>
      </section>

      <footer className="site-footer">
        <div className="footer-inner">
          <a href="#bosh" className="brand">
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>
          <p>Salomatlik haqida ishonchli ma’lumotlar.</p>
          <a
            href="https://www.youtube.com/@Neurocardiouz"
            target="_blank"
            rel="noopener noreferrer"
          >
            YouTube ↗
          </a>
        </div>
        <div className="footer-bottom">
          © {year} NeuroCardio. Barcha huquqlar himoyalangan.
        </div>
      </footer>
    </main>
  );
}
