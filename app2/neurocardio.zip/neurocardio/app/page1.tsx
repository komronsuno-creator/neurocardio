
"use client";

import { useEffect, useState } from "react";

const doctors = [
  {
    name: "Sobitjon Qurbonov",
    role: "Nevrolog",
    description: "Nevrologiya mutaxassisi",
    image: "/doctor-1.png",
    phone: "+998909105501",
    telegram: "https://t.me/sobitjon_090",
  },
  {
    name: "Saidburxon Turgunboyev",
    role: "Kardiolog",
    description: "Kardiologiya mutaxassisi",
    image: "/doctor-2.png",
    phone: "+998976305959",
    telegram: "https://t.me/Drsaidburxon",
  },
];

const directions = [
  {
    icon: "🧠",
    title: "Nevrologiya",
    text: "Miya va asab tizimi salomatligi",
  },
  {
    icon: "❤️",
    title: "Kardiologiya",
    text: "Yurak va qon bosimi haqida",
  },
  {
    icon: "🛡️",
    title: "Profilaktika",
    text: "Kasalliklarning oldini olish",
  },
  {
    icon: "🌙",
    title: "Uyqu va stress",
    text: "Sog‘lom uyqu va ruhiy salomatlik",
  },
];

const videos = [
  { id: "Ok1ZAK3LvRA", title: "Parkinson kasalligi — sabablari" },
  { id: "LW7kcd6s_OI", title: "Yurak nega og‘riydi?" , start: 55 },
  { id: "ZUxBWlhH37g", title: "Bosh aylanishi — sabablari" },
];

export default function Home() {
  const [activeDoctor, setActiveDoctor] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState("");

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveDoctor((current) => (current === 0 ? 1 : 0));
    }, 4500);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    elements.forEach((element) => observer.observe(element));

    return () => observer.disconnect();
  }, []);

  function handleAppointment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const doctor = doctors.find((item) => item.name === selectedDoctor);

    if (!doctor) {
      alert("Iltimos, avval shifokorni tanlang.");
      return;
    }

    window.open(doctor.telegram, "_blank", "noopener,noreferrer");
  }

  const currentDoctor = doctors[activeDoctor];

  return (
    <main className="site-shell">
      <header className="site-header">
        <nav className="nav-wrap">
          <a href="#bosh" className="brand" onClick={() => setMenuOpen(false)}>
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>

          <button
            type="button"
            className="mobile-menu-button"
            aria-label="Menyuni ochish"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? "✕" : "☰"}
          </button>

          <div className={`nav-links ${menuOpen ? "nav-open" : ""}`}>
            <a href="#yonalishlar" onClick={() => setMenuOpen(false)}>Yo‘nalishlar</a>
            <a href="#shifokorlar" onClick={() => setMenuOpen(false)}>Shifokorlar</a>
            <a href="#videolar" onClick={() => setMenuOpen(false)}>Videolar</a>
            <a href="#qabul" onClick={() => setMenuOpen(false)}>Qabul</a>
            <a className="nav-cta" href="#qabul" onClick={() => setMenuOpen(false)}>
              Qabulga yozilish ↗
            </a>
          </div>
        </nav>
      </header>

      <section id="bosh" className="hero-section">
        <div className="hero-glow hero-glow-one" />
        <div className="hero-glow hero-glow-two" />

        <div className="hero-layout">
          <div className="hero-copy reveal">
            <span className="eyebrow">
              MIYA · YURAK · SALOMATLIK
            </span>

            <h1>
              Sog‘lom hayot
              <span> ishonchli bilimdan</span>
              boshlanadi
            </h1>

            <p className="hero-description">
              Nevrologiya, kardiologiya va umumiy salomatlik haqida
              shifokorlar tayyorlagan sodda va ishonchli ma’lumotlar.
            </p>

            <div className="hero-actions">
              <a className="button-primary" href="#qabul">
                Qabulga yozilish <span>↗</span>
              </a>
              <a className="button-secondary" href="#videolar">
                <span>▶</span> Videolarni ko‘rish
              </a>
            </div>

            <div className="hero-stats">
              <div>
                <strong>100+</strong>
                <span>Tibbiy videolar</span>
              </div>
              <div>
                <strong>2</strong>
                <span>Mutaxassis</span>
              </div>
              <div>
                <strong>24/7</strong>
                <span>Foydali bilimlar</span>
              </div>
            </div>
          </div>

          <div className="hero-visual reveal">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />

            <div className="hero-glass-card">
              <div className="floating-label label-neuro">
                <span>🧠</span>
                <small>Nevrologiya</small>
              </div>

              <div className="floating-label label-cardio">
                <span>❤️</span>
                <small>Kardiologiya</small>
              </div>

              {doctors.map((doctor, index) => (
                <img
                  key={doctor.image}
                  src={doctor.image}
                  alt={doctor.name}
                  className={`hero-doctor-image ${
                    activeDoctor === index ? "doctor-active" : ""
                  }`}
                  aria-hidden={activeDoctor !== index}
                />
              ))}

              <div className="doctor-caption">
                <span className="live-dot" />
                <div>
                  <strong>{currentDoctor.name}</strong>
                  <span>{currentDoctor.role}</span>
                </div>
                <span className="caption-heart">♥</span>
              </div>
            </div>

            <div className="hero-bottom-note">
              <span>✦</span>
              Salomatligingiz biz uchun muhim
            </div>
          </div>
        </div>

        <a href="#yonalishlar" className="scroll-cue" aria-label="Pastga tushish">
          <span />
        </a>
      </section>

      <section id="yonalishlar" className="section section-directions">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">BIZNING YO‘NALISHLAR</span>
            <h2>Salomatlik uchun muhim bilimlar</h2>
            <p>
              Organizmni tushunish, sog‘lom odatlarni shakllantirish va
              kasalliklarning oldini olish haqida.
            </p>
          </div>

          <div className="direction-grid">
            {directions.map((item, index) => (
              <article
                key={item.title}
                className="direction-card glass-card reveal"
                style={{ transitionDelay: `${index * 90}ms` }}
              >
                <div className="direction-icon">{item.icon}</div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <a href="#videolar">Batafsil <span>↗</span></a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="shifokorlar" className="section section-doctors">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">MUTAXASSISLAR</span>
            <h2>Shifokorlarimiz</h2>
            <p>
              Mutaxassislar bilan bog‘laning va o‘zingizga kerakli
              ma’lumotni oling.
            </p>
          </div>

          <div className="doctor-grid">
            {doctors.map((doctor, index) => (
              <article
                key={doctor.name}
                className="doctor-card glass-card reveal"
                style={{ transitionDelay: `${index * 120}ms` }}
              >
                <div className="doctor-photo-wrap">
                  <img src={doctor.image} alt={doctor.name} />
                  <span className="doctor-specialty">{doctor.role}</span>
                </div>
                <div className="doctor-card-body">
                  <span className="doctor-kicker">NEUROCARDIO MUTAXASSISI</span>
                  <h3>{doctor.name}</h3>
                  <p>{doctor.description}</p>
                  <div className="doctor-card-actions">
                    <a className="button-primary" href={doctor.telegram} target="_blank" rel="noreferrer">
                      Telegram ↗
                    </a>
                    <a className="phone-link" href={`tel:${doctor.phone}`}>
                      ☎ Qo‘ng‘iroq
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="videolar" className="section section-videos">
        <div className="section-container">
          <div className="section-heading reveal">
            <span className="eyebrow">VIDEO KUTUBXONASI</span>
            <h2>Foydali tibbiy videolar</h2>
            <p>
              NeuroCardio kanalidagi salomatlik haqidagi videolarni shu
              sahifaning o‘zida tomosha qiling.
            </p>
          </div>

          <div className="video-grid">
            {videos.map((video, index) => (
              <article
                key={video.id}
                className="video-card glass-card reveal"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="video-frame">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${video.id}${
                      video.start ? `?start=${video.start}` : ""
                    }`}
                    title={video.title}
                    loading="lazy"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                  />
                </div>
                <div className="video-info">
                  <span>NEUROCARDIO · VIDEO</span>
                  <h3>{video.title}</h3>
                </div>
              </article>
            ))}
          </div>

          <div className="channel-link-wrap reveal">
            <a
              className="button-secondary"
              href="https://www.youtube.com/@Neurocardiouz"
              target="_blank"
              rel="noreferrer"
            >
              YouTube kanaliga o‘tish ↗
            </a>
          </div>
        </div>
      </section>

      <section id="qabul" className="section section-appointment">
        <div className="section-container appointment-layout">
          <div className="appointment-copy reveal">
            <span className="eyebrow">BIZ BILAN BOG‘LANING</span>
            <h2>Salomatligingizga bugundan e’tibor bering</h2>
            <p>
              Kerakli shifokorni tanlang. Sizni tegishli mutaxassisning
              Telegram sahifasiga yo‘naltiramiz.
            </p>
            <div className="appointment-points">
              <span>✓ Mutaxassisni tanlash</span>
              <span>✓ Telegram orqali bog‘lanish</span>
              <span>✓ Qulay va sodda</span>
            </div>
          </div>

          <form className="appointment-form glass-card reveal" onSubmit={handleAppointment}>
            <label htmlFor="patient-name">Ism va familiyangiz</label>
            <input
              id="patient-name"
              name="name"
              type="text"
              placeholder="Ismingizni kiriting"
              autoComplete="name"
              required
            />

            <label htmlFor="patient-phone">Telefon raqamingiz</label>
            <input
              id="patient-phone"
              name="phone"
              type="tel"
              placeholder="+998 __ ___ __ __"
              autoComplete="tel"
              required
            />

            <label htmlFor="doctor-select">Shifokorni tanlang</label>
            <select
              id="doctor-select"
              value={selectedDoctor}
              onChange={(event) => setSelectedDoctor(event.target.value)}
              required
            >
              <option value="">Shifokorni tanlang</option>
              {doctors.map((doctor) => (
                <option key={doctor.name} value={doctor.name}>
                  {doctor.name} — {doctor.role}
                </option>
              ))}
            </select>

            <button className="button-primary form-submit" type="submit">
              Telegram orqali bog‘lanish <span>↗</span>
            </button>

            <p className="form-note">
              Tugma tanlangan shifokorning Telegram sahifasini ochadi.
              Ism va telefon raqami avtomatik yuborilmaydi.
            </p>
          </form>
        </div>
      </section>

      <footer className="site-footer">
        <div className="footer-inner">
          <a href="#bosh" className="brand">
            <span className="brand-heart">♥</span>
            NeuroCardio
          </a>
          <p>Salomatlik haqida ishonchli ma’lumotlar.</p>
          <a href="https://www.youtube.com/@Neurocardiouz" target="_blank" rel="noreferrer">
            YouTube ↗
          </a>
        </div>
        <div className="footer-bottom">
          © {new Date().getFullYear()} NeuroCardio. Barcha huquqlar himoyalangan.
        </div>
      </footer>
    </main>
  );
}
